/*
    Destruktor fuer dynamisch erzeugte Objekte fehlt.

    In diesem Beispiel wird eine selbst gebaute dynamische Liste verwendet. Um beliebige
    Elemente in der Liste ablegen zu koennen wurde sie in eine Template-Klasse umgeformt
*/
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>
#include <QMouseEvent>
#include <QPainter>
#include "figur.h"
#include "linie.h"
#include "dreieck.h"
#include "viereck.h"
#include "kreis.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    state = 0;          // Zeichenmode: 0-noch nichts, 1-Linie start ...
    p = new QPainter(this);

    qApp->installEventFilter(this);
}

// Methode mit der gezeichnet wird
void MainWindow::paintEvent(QPaintEvent *)
{
    p = new QPainter(this);

    /*
    for (std::vector<Figur*>::iterator it = list.begin(); it != list.end(); it++) { // fertige Objekte
        (*it)->draw(p);
    }*/
    for (int i = 0; i < list.size(); i++) {
        list.get(i)->draw(p);
    }

    if (state > 0)              // noch in Erstellung
        list.getLetztefig()->draw(p);
        // list.back()->draw(p);     // working for vector-list
    delete(p);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::mousePressEvent(QMouseEvent *event) {
    if (state > 0)
        //state = list.back()->step(state, event->pos());   // working for vector-list
        state = list.getLetztefig()->step(state, event->pos());
    if (state == 99) {
        state = 0;
    }
    repaint();
}

bool MainWindow::eventFilter(QObject *, QEvent *event)
{
    if (event->type() == QEvent::MouseMove)     // MouseMove-Event
    {
        if (state > 0) {
            QMouseEvent *mouseEvent = static_cast<QMouseEvent*>(event);
            statusBar()->showMessage(QString("Mouse move (%1,%2)").arg(mouseEvent->pos().x()).arg(mouseEvent->pos().y()));
            //list.back()->step(state, mapFromGlobal(mouseEvent->globalPos()));   // working for vector-list
            list.getLetztefig()->step(state, mapFromGlobal(mouseEvent->globalPos()));
            repaint();
        }
    }
  return false;
}

void MainWindow::on_action_Linie_triggered()
{
    if (state == 0) {
        qDebug() << "Linien Zeichnen Beginn";
        state = 1;
        //list.push_back(new Linie(Qt::red));   // working for vector-list
        list.add(new Linie(Qt::red));
    }
}

void MainWindow::on_actionDreieck_triggered()
{
    if (state == 0) {
        qDebug() << "Dreieck Zeichnen Beginn";
        state = 1;
        //list.push_back(new Dreieck(Qt::blue));    // working for vector-list
        list.add(new Dreieck(Qt::blue));
    }
}

void MainWindow::on_actionViereck_triggered()
{
    if (state == 0) {
        qDebug() << "Viereck Zeichnen Beginn";
        state = 1;
        //list.push_back(new Viereck(Qt::yellow));  // working for vector-list
        list.add(new Viereck(Qt::yellow));
    }
}

void MainWindow::on_action_Kreis_triggered()
{
    if (state == 0) {
        qDebug() << "Kreis Zeichnen Beginn";
        state = 1;
        //list.push_back(new Kreis(Qt::magenta));   // working for vector-list
        list.add(new Kreis(Qt::magenta));
    }
}
