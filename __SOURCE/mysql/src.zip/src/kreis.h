#ifndef KREIS_H
#define KREIS_H

#include <QPainter>
#include "figur.h"

class Kreis : public Figur
{
public:
    Kreis(Qt::GlobalColor pen);
    virtual ~Kreis();
    void draw(QPainter *p);
    int step(int state, QPoint pos);

    QPoint m_pt1;
    QPoint m_pt2;
};

#endif // KREIS_H
