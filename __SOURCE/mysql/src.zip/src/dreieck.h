#ifndef DREIECK_H
#define DREIECK_H

#include <QPainter>
#include "figur.h"

class Dreieck : public Figur
{
public:
    Dreieck(Qt::GlobalColor pen);
    virtual ~Dreieck();
    void draw(QPainter *p);
    int step(int state, QPoint pos);

    QPoint m_pt1;
    QPoint m_pt2;
    QPoint m_pt3;
};

#endif // DREIECK_H
