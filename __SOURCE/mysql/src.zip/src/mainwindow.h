#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPainter>
#include <vector>
#include "liste.h"
#include "figur.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void mousePressEvent(QMouseEvent *event);
    void paintEvent(QPaintEvent *);
    bool eventFilter(QObject *obj, QEvent *event);

    QPainter *p;

private slots:

    void on_action_Linie_triggered();

    void on_actionDreieck_triggered();

    void on_actionViereck_triggered();

    void on_action_Kreis_triggered();

private:
    Ui::MainWindow *ui;
    //Figur *list[10];          // working array
    //std::vector<Figur*> list; // working list
    Liste<Figur> list;
    int state;
};

#endif // MAINWINDOW_H
