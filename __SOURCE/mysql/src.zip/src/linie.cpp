#include <QPainter>
#include "linie.h"

Linie::Linie(Qt::GlobalColor pen) : Figur(pen)
{
    m_pt1 = QPoint(0,0);
    m_pt2 = QPoint(0,0);
}
Linie::~Linie(){}

void Linie::draw(QPainter *p) {
    p->setPen(m_pen);
    p->drawLine(m_pt1,m_pt2);
}

int Linie::step(int state, QPoint pos) {
    if (state == 1) {
        m_pt1 = pos;
        m_pt2 = pos;
        return 2;
    } else if (state == 2) {
        m_pt2 = pos;
        return 99;
    }
    return state;
}

