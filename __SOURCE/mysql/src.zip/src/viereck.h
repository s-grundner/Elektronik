#ifndef VIERECK_H
#define VIERECK_H

#include <QPainter>
#include "figur.h"

class Viereck : public Figur
{
public:
    Viereck(Qt::GlobalColor pen);
    virtual ~Viereck();
    void draw(QPainter *p);
    int step(int state, QPoint pos);

    QPoint m_pt1;
    QPoint m_pt2;
    QPoint m_pt3;
    QPoint m_pt4;
};

#endif // VIERECK_H
