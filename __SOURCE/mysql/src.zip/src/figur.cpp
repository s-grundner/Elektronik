#include <QPainter>
#include "figur.h"

Figur::Figur(Qt::GlobalColor pen)
{
    m_pen = pen;
}

Figur::~Figur()
{

}
