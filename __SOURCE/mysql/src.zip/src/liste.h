#ifndef LISTE_H
#define LISTE_H
#include "figur.h"

template <typename T>
struct myElem
{
    T *fig;
    myElem<T> *next;
};

template <typename T>
class Liste
{
public:
    Liste();
    ~Liste();
    Liste *add(T *num);
    T *get(int pos);
    int size();
    Liste *clear();
    int erase(int pos);
    int insert(int pos, T *fig);
    myElem<T> *begin();
    myElem<T> *end();
    T *getLetztefig();

private:
    myElem<T> *erste;
    myElem<T> *letzte;
    int length;
};

template <typename T>
Liste<T>::Liste()
{
    length = 0;
    erste = nullptr;
    letzte = nullptr;
}
template <typename T>
Liste<T>::~Liste() {
    this->clear();
}
template <typename T>
Liste<T> *Liste<T>::add(T *fig) {

    if (letzte != nullptr) {
        letzte->next = new myElem<T>;
        letzte = letzte->next;
        letzte->fig = fig;
    } else {
        erste = new myElem<T>;
        letzte = erste;
        erste->fig = fig;
    }
    length++;
    return this;
}
template <typename T>
T *Liste<T>::get(int pos) {
    if ((pos < length) && (pos >= 0)) {
        myElem<T> *tmp = erste;
        for (int i = 0; i < pos; i++) {
            tmp = tmp->next;
        }
        return tmp->fig;

    } else {
        return nullptr;       // Exception notwendig!
    }
}
template <typename T>
int Liste<T>::size() {
    return length;
}
template <typename T>
int Liste<T>::erase(int pos) {
    myElem<T> *tmp = erste;
    if ((pos < length) && (pos == 0)) {
        erste = erste->next;
    }
    if ((pos < length) && (pos > 0)) {
        myElem<T> *tmp1 = nullptr;
        for (int i = 0; i < pos; i++) {
            tmp1 = tmp;
            tmp = tmp->next;
        }
        tmp1->next = tmp->next;
    }
    else {
        return -1;
    }
    delete(tmp);
    length--;
    return length;
}
template <typename T>
Liste<T> *Liste<T>::clear() {
    myElem<T> *tmp = erste;
    for (int i = 0; i < length; i++) {
        myElem<T> *tmp1 = tmp;
        tmp = tmp->next;
        delete(tmp1);
    }
    length = 0;
    erste = letzte = nullptr;
    return this;
}
template <typename T>
int Liste<T>::insert(int pos, T *fig) {
    myElem<T> *tmp = erste;
    if (pos == 0) {
        erste = new myElem<T>;
        erste->fig = fig;
        erste->next = tmp;
    }
    else if ((pos >0) && (pos <= length)) {
        myElem<T> *tmp1 = tmp;
        for (int i = 0; i < pos; i++) {
            tmp1 = tmp;
            tmp = tmp->next;
        }
        tmp1->next = new myElem<T>;
        tmp1->next->fig = fig;
        tmp1->next->next = tmp;
    } else return -1;
    length++;
    return length;
}
template <typename T>
myElem<T> *Liste<T>::begin() {
    return erste;
}
template <typename T>
myElem<T> *Liste<T>::end() {
    return letzte;
}
template <typename T>
T *Liste<T>::getLetztefig() {
    return letzte->fig;
}

#endif // LISTE_H
