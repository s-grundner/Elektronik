#ifndef FIGUR_H
#define FIGUR_H
#include <QPainter>

class Figur
{
public:
    Figur(Qt::GlobalColor pen);
    virtual ~Figur();
    virtual void draw(QPainter *p) = 0;
    virtual int step(int state, QPoint pos) = 0;
protected:
    Qt::GlobalColor m_pen;
};

#endif // FIGUR_H
