#include <QPainter>
#include "kreis.h"

Kreis::Kreis(Qt::GlobalColor pen) : Figur(pen)
{
    m_pt1 = QPoint(0,0);
    m_pt2 = QPoint(0,0);
}
Kreis::~Kreis(){}

void Kreis::draw(QPainter *p) {
    p->setPen(m_pen);
    p->drawEllipse(QRect(m_pt1, m_pt2));
}

int Kreis::step(int state, QPoint pos) {
    if (state == 1) {
        m_pt1 = pos;
        m_pt2 = pos;
        return 2;
    } else if (state == 2) {
        m_pt2 = pos;
        return 99;
    }
    return state;
}

