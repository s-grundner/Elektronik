#include <QPainter>
#include "viereck.h"

Viereck::Viereck(Qt::GlobalColor pen) : Figur(pen)
{
    m_pt1 = QPoint(0,0);
    m_pt2 = QPoint(0,0);
    m_pt3 = QPoint(0,0);
    m_pt4 = QPoint(0,0);
}
Viereck::~Viereck(){}

void Viereck::draw(QPainter *p) {
    p->setPen(m_pen);
    p->drawLine(m_pt1,m_pt2);
    p->drawLine(m_pt2,m_pt3);
    p->drawLine(m_pt3,m_pt4);
    p->drawLine(m_pt4,m_pt1);
}

int Viereck::step(int state, QPoint pos) {
    if (state == 1) {
        m_pt1 = pos;
        m_pt2 = pos;
        m_pt3 = pos;
        m_pt4 = pos;
        return 2;
    } else if (state == 2) {
        m_pt2 = pos;
        m_pt3 = pos;
        return 3;
    } else if (state == 3) {
        m_pt3 = pos;
        m_pt4 = pos;
        return 4;
    } else if (state == 4) {
        m_pt4 = pos;
        return 99;
    }
    return state;
}

