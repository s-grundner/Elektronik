#ifndef LINIE_H
#define LINIE_H

#include <QPainter>
#include "figur.h"

class Linie : public Figur
{
public:
    Linie(Qt::GlobalColor pen);
    virtual ~Linie();
    void draw(QPainter *p);
    int step(int state, QPoint pos);

    QPoint m_pt1;
    QPoint m_pt2;
};

#endif // LINIE_H
